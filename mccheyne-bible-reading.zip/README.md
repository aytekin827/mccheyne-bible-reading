# mccheyne-bible-reading
Mccheyne bible reading chrome extension

this extension will be shown in shape of pop-up and user can check whether read or not on that day.

**I hope that this will help to make great habit for christian who love Jesus!**
